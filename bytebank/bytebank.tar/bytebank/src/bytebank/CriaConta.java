package bytebank;

public class CriaConta {
	
	public static void main(String[] args) {
		
		Conta primeriraConta = new Conta();
		//primeriraConta.saldo = 200;
		
		Conta segundaConta = new Conta();
		//segundaConta.saldo = 50;
		
		//System.out.println("primeira conta tem " + primeriraConta.saldo);
		//System.out.println("segunda conta tem " + segundaConta.saldo);
		
	}

}
